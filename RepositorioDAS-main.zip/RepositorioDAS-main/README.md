
# FORO-1-WPF
 Ejemplo de Aplicacion realizada en WPF 
 


## Cómo Ejecutar la Aplicación

1. Descargar Zip.
3. Abre el proyecto en Visual Studio (.NET 6).
4. Ejecuta la aplicación.



## calculadora

 realizar operaciones cómo: suma, resta, multiplicación, división, Raiz cuadrada, Elevar al cuadrado y Borrar tanto operacion completa como numeros.

